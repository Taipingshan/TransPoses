import numpy as np
idx = [1,3,5]
for i in range(6):
    if i not in idx:
        print(i)