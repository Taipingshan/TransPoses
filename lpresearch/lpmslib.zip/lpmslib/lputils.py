

#helpers
def logd(tag, msg):
    print("[Debug-"+tag+"]", msg)

def loge(tag, msg):
    print("[Error-"+tag+"]", msg)
